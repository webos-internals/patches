var CallAction = PropertyBase.create({
	data: [
		{
			dbFieldName: "action",
			defaultValue: "",
			setterName: "setAction",
			getterName: "getAction"
		}
	]
});
