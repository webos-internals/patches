enyo.kind({
	name: "PhoneAppPrefs",
	kind: "VFlexBox",
	className: "enyo-bg",
	
	components: [
		{kind: "RowGroup", caption: $L("DEFAULT PHONE VIEW"), components: [
			{kind: "ListSelector", value: "default", name: "defaultViewPref", onChange: "onDefaultViewChanged"}
		]},
		
		{kind: "RowGroup", caption: $L("APPLICATION"), components: [
			{layoutKind: "HFlexLayout", align: "center", tapHighlight: false, components: [
				{flex: 1, content: $L("Contact Matching")},
				{name: "showContactMatchField", kind: "ToggleButton", onChange: "onMatchValueChanged"}
			]},
			{layoutKind: "HFlexLayout", components: [
				{content: $L("Close After Call"), style: "padding-top: 5px;", flex: 1},
				{kind: "ToggleButton", name: "closeAfterPref", onChange: "onCloseAfterChanged"}
			]}
		]},
		
		{kind: "RowGroup", caption: $L("AUTOMATION"), components: [
			{kind: "ListSelector", value: "call", label: $L("On Dial Select"), name: "dialSelectPref", onChange: "onDialSelectChanged"},
			{kind: "ListSelector", value: "answer", label: $L("On TS Removal"), name: "tsRemovalPref", onChange: "onTSRemovalChanged"},
			{kind: "ListSelector", value: "none", label: $L("On Proximity"), name: "proximityEventPref", onChange: "onProximityEventChanged"},
			{kind: "ListSelector", value: "none", label: $L("On Call Reject"), name: "callRejectPref", onChange: "onCallRejectChanged"},
			{kind: "Input", value: "", hint: $L("Template text for auto reply..."), name: "autoReplyPref", onchange: "onAutoReplyChanged"}
		]},
		
		{name: "getAppPreferences", kind: enyo.PalmService, service: enyo.palmServices.system, method: "getPreferences", onSuccess: "updatePreferences", onFailure: "updatePreferences"},
		{name: "setAppPreferences", kind: enyo.PalmService, service: enyo.palmServices.system, method: "setPreferences"}
	],
	
	create: function() {
		this.inherited(arguments);
		
		this.defaultViewPrefItems = [
			{caption: $L("No Default View"), value: "default"}, 
			{caption: $L("Dialpad"), value: "dialpad"},
			{caption: $L("Call Log"), value: "calllog"},
			{caption: $L("Favorites"), value: "favorites"} ];
		
		this.$.defaultViewPref.setItems(this.defaultViewPrefItems);
		
		this.dialSelectPrefItems = [
			{caption: $L("Do Nothing"), value: "none"}, 
			{caption: $L("Start Call"), value: "call"} ];
		
		this.$.dialSelectPref.setItems(this.dialSelectPrefItems);
		
		this.tsRemovalPrefItems = [
			{caption: $L("Do Nothing"), value: "none"}, 
			{caption: $L("Answer Call"), value: "answer"} ];
		
		this.$.tsRemovalPref.setItems(this.tsRemovalPrefItems);
		
		this.proximityEventPrefItems = [
			{caption: $L("Do Nothing"), value: "none"}, 
			{caption: $L("Change Audio"), value: "change"} ];
		
		this.$.proximityEventPref.setItems(this.proximityEventPrefItems);
		
		this.callRejectPrefItems = [
			{caption: $L("Do Nothing"), value: "none"}, 
			{caption: $L("Send SMS Reply"), value: "autoreply"} ];
		
		this.$.callRejectPref.setItems(this.callRejectPrefItems);
		
		this.loadPreferences();
	},
	
	loadPreferences: function() {
		if((localStorage) && (localStorage["phonePrefs"]))
			this.phonePrefs = enyo.json.parse(localStorage["phonePrefs"]);
		else {
			this.phonePrefs = {
				version: 1,
				closeApp: false,
				startView: "default",
				autoDialing: "call",
				removedFromTS: "answer",
				proximityAction: "none" };
		}
		
		this.$.defaultViewPref.setValue(this.phonePrefs.startView);
		this.$.closeAfterPref.setState(this.phonePrefs.closeApp);
		
		this.$.dialSelectPref.setValue(this.phonePrefs.autoDialing);
		this.$.tsRemovalPref.setValue(this.phonePrefs.removedFromTS);
		this.$.proximityEventPref.setValue(this.phonePrefs.proximityAction);
		
		this.rejectedPrefs = {
			rejectAction: "none",
			rejectTemplate: "Sorry, I am currently busy and will call you back later..." };
		
		this.$.getAppPreferences.call({
			keys: ["callRejection", "showcontactmatch"]
		});
	},
	
	updatePreferences: function(inSender, inResponse) {
		if((inResponse) && (inResponse.returnValue)) {
			if(inResponse.callRejection)
				this.rejectedPrefs = inResponse.callRejection;
			
			if(inResponse.showcontactmatch != undefined)
				this.$.showContactMatchField.setState(inResponse.showcontactmatch);
			else
				this.$.showContactMatchField.setState(true);
		}
		
		this.$.callRejectPref.setValue(this.rejectedPrefs.rejectAction);
		this.$.autoReplyPref.setValue($L(this.rejectedPrefs.rejectTemplate));
		
		if(this.rejectedPrefs.rejectAction == "none")
			this.$.autoReplyPref.hide();
	},
	
	onDefaultViewChanged: function() {
		this.phonePrefs.startView = this.$.defaultViewPref.getValue();
		
		localStorage["phonePrefs"] = enyo.json.stringify(this.phonePrefs);
	},
	
	onMatchValueChanged: function () {
		var state = this.$.showContactMatchField.getState();
		
		this.$.setAppPreferences.call({ showcontactmatch: state });
	},
	onCloseAfterChanged: function() {
		this.phonePrefs.closeApp = this.$.closeAfterPref.getState();
		
		localStorage["phonePrefs"] = enyo.json.stringify(this.phonePrefs);
	},
	
	onDialSelectChanged: function() {
		this.phonePrefs.autoDialing = this.$.dialSelectPref.getValue();
		
		localStorage["phonePrefs"] = enyo.json.stringify(this.phonePrefs);
	},
	onTSRemovalChanged: function() {
		this.phonePrefs.removedFromTS = this.$.tsRemovalPref.getValue();
		
		localStorage["phonePrefs"] = enyo.json.stringify(this.phonePrefs);
	},
	onProximityEventChanged: function() {
		this.phonePrefs.proximityAction = this.$.proximityEventPref.getValue();
		
		localStorage["phonePrefs"] = enyo.json.stringify(this.phonePrefs);
	},
	onCallRejectChanged: function() {
		this.rejectedPrefs.rejectAction = this.$.callRejectPref.getValue();
		
		if(this.rejectedPrefs.rejectAction == "none")
			this.$.autoReplyPref.hide();
		else
			this.$.autoReplyPref.show();
		
		this.$.setAppPreferences.call({ callRejection: this.rejectedPrefs });
	},
	onAutoReplyChanged: function() {
		this.rejectedPrefs.rejectTemplate = this.$.autoReplyPref.getValue();
		
		this.$.setAppPreferences.call({ callRejection: this.rejectedPrefs });
	}
});

