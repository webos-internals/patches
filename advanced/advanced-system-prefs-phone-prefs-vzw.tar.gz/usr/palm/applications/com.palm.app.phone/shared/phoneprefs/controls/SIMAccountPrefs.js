enyo.kind({
	name: "SIMAccountPrefs",
	kind: "VFlexBox",
	className: "enyo-bg",
	
	events: {
		updateCardUI: ""
	},
	
	components: [
		{name: "pane", kind:"Pane", flex: 1, components: [
			{name: "main", kind: "Scroller", className: "", components: [
				{ kind: "PageHeader", className: "header", components: [
					{name: "photoImage", kind: "Image", style: "padding-right: 6px;", className: "phone-icon", src: "../shared/phoneprefs/images/header-icon-phone.png"},
					{name: "pageHeader", content: $L("SIM Account Settings"), className: "phone-header-caption"},
				]}, 
				{style: "padding: 5px;", components: [
					{name: "phoneNumberScene", kind: "PhoneNumberPref"},
					{name: "voicemailNumberScene", kind: "VoicemailNumber"},
					{name: "securityView", kind: "Security", onRefreshCard: "refreshCardUI"}
				]},
			]},
		]}
	],
	
	create: function() {
		this.inherited(arguments);
	},
	
	updateUI: function(platformType) {
		this.$.securityView.checkfdnUI();
		this.$.securityView.updateUI();
		
		this.$.phoneNumberScene.updateUI();
		
		if(platformType == "cdma")
			this.$.voicemailNumberScene.hide();
		else {
			this.$.voicemailNumberScene.show();
			this.$.voicemailNumberScene.updateUI();
		}
	},
	
	refreshCardUI: function() {
		this.$.securityView.updateUI();
		
		this.doUpdateCardUI();
	}
});

