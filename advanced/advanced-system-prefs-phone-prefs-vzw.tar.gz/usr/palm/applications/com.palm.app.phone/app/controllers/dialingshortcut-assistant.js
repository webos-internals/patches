var DialingshortcutAssistant = Class.create({
	initialize: function(prefsSceneAssistant) {
		this.prefsSceneAssistant = prefsSceneAssistant;
	},
	
	setup: function() {
		this.digitList = [
			{label:$L('3 digits'), value:"3DigitNumber"}, 
			{label:$L('4 digits'), value:"4DigitNumber"}, 
			{label:$L('5 digits'), value:"5DigitNumber"}, 
			{label:$L('6 digits'), value:"6DigitNumber"}, 
			{label:$L('7 digits'), value:"7DigitNumber"} ];
		
		this.digitListModel = {
			currentSelection: '4DigitNumber', 
			choices: this.digitList };
		
		this.dsAttributes = {
			hintText: $L('Enter number'), 
			modelProperty: 'number', 
			modifierState: Mojo.Widget.numLock, 
			focusMode: Mojo.Widget.focusInsertMode, 
			disabledProperty: 'p', 
			changeOnKeyPress: true, 
			charsAllow: Mojo.Widget.numericValidation, 
			maxLength: 50 };
		
		this.shortcutNumbermodel = { p: false, 'number': '' };
		
		this.controller.setupWidget('shortcut_prefix', this.dsAttributes, this.shortcutNumbermodel);
		this.controller.get('shortcut_prefix').observe(Mojo.Event.propertyChange, this.propertyChanged.bind(this));
		
		this.controller.setupWidget('listDigits_selector', {modelProperty:'currentSelection'}, this.digitListModel);			
		this.controller.get('listDigits_selector').addEventListener(Mojo.Event.propertyChange, this.handleDigitSelection.bindAsEventListener(this));
		
		this.doneButtonModel = { buttonLabel: $L("Done"), disabled:true };
		
		this.controller.setupWidget('done_button', {}, this.doneButtonModel);
		this.controller.get('done_button').addEventListener(Mojo.Event.tap, this.handleDone.bindAsEventListener(this));
		
		var appMenuModel = {
			visible: true, items: [Mojo.Menu.editItem, {label:$L('Help'), command:Mojo.Menu.helpCmd}] };
		
		this.controller.setupWidget(Mojo.Menu.appMenu, {omitDefaultItems:true}, appMenuModel);
		
		this.controller.setInitialFocusedElement(null);
	},
	
	handleCommand: function(event) {
		if(event.type == Mojo.Event.command) {
			if(event.command == Mojo.Menu.helpCmd) {
				var r = new Mojo.Service.Request('palm://com.palm.applicationManager', {
					method: 'open', parameters: {'id': 'com.palm.app.help', params: {
						'target': 'http://help.palm.com/phone/phone_prefs/index.html'}}});
			}
		}
	},
	
	handleDigitSelection: function(event) {
		if(!event.value)
			return;
	},
	
	propertyChanged: function(event) {
		if(this.shortcutNumbermodel.number.length > 0)
			this.doneButtonModel.disabled = false;
		else
			this.doneButtonModel.disabled = true;
		
		this.controller.modelChanged(this.doneButtonModel);
	},
	
	handleDone: function() {
		var params = {};
		
		var object = {
			text: this.digitListModel.currentSelection, 
			value: this.shortcutNumbermodel.number };
		
		params[this.digitListModel.currentSelection] = this.shortcutNumbermodel.number;
		
		this.setPreferencesRequest = new Mojo.Service.Request('palm://com.palm.systemservice/', {
			method: 'setPreferences', parameters: params});
		
		this.prefsSceneAssistant.dialingShortCutAdded(object);
		
		var appController = Mojo.Controller.getAppController();
		
		var stageController = appController.getStageController("PhoneApp");
		
		stageController.popScene();
	}
});

