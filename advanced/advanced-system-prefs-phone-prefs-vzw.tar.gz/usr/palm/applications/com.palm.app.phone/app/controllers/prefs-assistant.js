var PrefsAssistant = Class.create({
	initialize: function(phonePrefs, rejectedPrefs, notificationPrefs) {
		this.phonePrefs = phonePrefs;
		this.rejectedPrefs = rejectedPrefs;
		this.notificationPrefs = notificationPrefs;
		
		this.dialingShortcutsList = [];
	},
	
	setup: function() {
		this.controller.document.body.className = "prefs";
		
		this.controller.setInitialFocusedElement(null);
		
		if(this.rejectedPrefs.rejectAction != "autoreply") {
			this.controller.get("RejectedCallRow").addClassName('last');
			this.controller.get("RejectedTextRow").hide();
		}
		
		this.modelMatchContacts = { value: true, disabled: false };
		
		this.controller.setupWidget('MatchContacts', {falseLabel: $L("Off"), trueLabel: $L("On")},
		   this.modelMatchContacts);
		
		this.controller.listen(this.controller.get("MatchContacts"), Mojo.Event.propertyChange, 
			this.savePreferences.bind(this));
		
		this.choicesstartView = [
			{label: $L("No Default View"), value: "default"},
			{label: $L("Dialpad"), value: "dialpad"},
			{label: $L("Call Log"), value: "calllog"},
			{label: $L("Favorites"), value: "favorites"} ];
		
		this.modelStartView = {value: this.phonePrefs.startView, disabled: false};
		
		this.controller.setupWidget("DefaultView", {labelPlacement: "right", 
			choices: this.choicesstartView}, this.modelStartView);
		
		this.controller.listen(this.controller.get("DefaultView"), Mojo.Event.propertyChange, 
			this.savePhonePrefs.bind(this));
		
		this.modelCloseAfter = { value: this.phonePrefs.closeApp, disabled: false };
		
		this.controller.setupWidget('CloseAfter', {falseLabel: $L("No"), trueLabel: $L("Yes")}, 
		   this.modelCloseAfter);
		
		this.controller.listen(this.controller.get("CloseAfter"), Mojo.Event.propertyChange, 
			this.savePhonePrefs.bind(this));
		
		this.choicesAutoDialing = [
			{label: $L("Do Nothing"), value: "none"},
			{label: $L("Start Call"), value: "call"} ];
		
		this.modelAutoDialing = {value: this.phonePrefs.autoDialing, disabled: false};
		
		this.controller.setupWidget("AutoDialing", {label: $L("On Dial Select"), 
			labelPlacement: "left", choices: this.choicesAutoDialing}, this.modelAutoDialing);
		
		this.controller.listen(this.controller.get("AutoDialing"), Mojo.Event.propertyChange, 
			this.savePhonePrefs.bind(this));
		
		this.choicesTouchstoneRemove = [
			{label: $L("Do Nothing"), value: "none"}, 
			{label: $L("Answer Call"), value: "answer"} ];
		
		this.modelTouchstoneRemove = {value: this.phonePrefs.removedFromTS, disabled: false};
		
		this.controller.setupWidget("TSAutoAnswer", {label: $L("On TS Removal"), 
			labelPlacement: "left", choices: this.choicesTouchstoneRemove}, this.modelTouchstoneRemove);
		
		this.controller.listen(this.controller.get("TSAutoAnswer"), Mojo.Event.propertyChange, 
			this.savePhonePrefs.bind(this));
		
		this.choicesProximityAction = [
			{label: $L("Do Nothing"), value: "none"}, 
			{label: $L("Change Audio"), value: "change"} ];
		
		this.modelProximityAction = {value: this.phonePrefs.proximityAction, disabled: false};
		
		this.controller.setupWidget("ProximityAction", {label: $L("On Proximity"), 
			labelPlacement: "left", choices: this.choicesProximityAction}, this.modelProximityAction);
		
		this.controller.listen(this.controller.get("ProximityAction"), Mojo.Event.propertyChange, 
			this.savePhonePrefs.bind(this));
		
		this.choicesRejectedCall = [
			{label: $L("Do Nothing"), value: "none"}, 
			{label: $L("Send SMS Reply"), value: "autoreply"} ];
		
		this.modelRejectedCall = {value: this.rejectedPrefs.rejectAction, disabled: false};
		
		this.controller.setupWidget("RejectedCall", {label: $L("On Call Reject"), 
			labelPlacement: "left", choices: this.choicesRejectedCall}, this.modelRejectedCall);
		
		this.controller.listen(this.controller.get("RejectedCall"), Mojo.Event.propertyChange, 
			this.saveRejectedPrefs.bind(this));
		
		this.modelRejectedText = {value: this.rejectedPrefs.rejectTemplate, disabled: false};
		
		this.controller.setupWidget("RejectedText", {'hintText': $L("Template text for auto reply..."), 
		'multiline': true, 'enterSubmits': false, 'autoFocus': false}, this.modelRejectedText); 
		
		this.controller.listen(this.controller.get("RejectedText"), Mojo.Event.propertyChange, 
			this.saveRejectedPrefs.bind(this));
		
		this.controller.listen(this.controller.get("phoneAccount"), Mojo.Event.tap, 
			this.launchPhoneAccount.bind(this));
		
		this.controller.listen(this.controller.get("notifications"), Mojo.Event.tap, 
			this.editNotifications.bind(this));
		
		this.dialingShortcutsModel = {listTitle: $L("Dialing Shortcuts"), items: this.dialingShortcutsList};
		
		this.controller.setupWidget('dialingShortcutsList', {itemTemplate: 'prefs/dialingshortcutitem',
			listTemplate: 'prefs/listcontainer', addItemLabel: $L("Add New Number"), swipeToDelete: true}, 
			this.dialingShortcutsModel);
		
		this.controller.get('dialingShortcutsList').addEventListener(Mojo.Event.listAdd, 
			this.addDialingShortcut.bindAsEventListener(this));
		
		this.controller.get('dialingShortcutsList').addEventListener(Mojo.Event.listDelete, 
			this.deleteDialingShortcut.bindAsEventListener(this));
		
		this.getPreferencesRequest = new Mojo.Service.Request('palm://com.palm.systemservice/', {
			method: 'getPreferences', parameters: {'keys': ["showcontactmatch", "3DigitNumber", 
				"4DigitNumber", "5DigitNumber", "6DigitNumber", "7DigitNumber"]}, 
			onSuccess: this.loadPreferences.bind(this) });
		
		this.getPhoneNumberRequest = new Mojo.Service.Request('palm://com.palm.telephony/', {
			method: 'phoneNumberQuery', onSuccess: this.updatePhoneNumber.bind(this), 
			onFailure: this.updatePhoneNumber.bind(this) });
	},
	
	cleanup: function() {
		this.controller.document.body.className = "palm-default";
	},
	
	updatePhoneNumber: function(response){
		if (response.returnValue == true && response.extended) {
			if (response.extended.number !== "bad_file_on_sim") {
				this.controller.get("phoneNumber").innerHTML = Globalization.Format.formatPhoneNumber(Globalization.Phone.parsePhoneNumber(response.extended.number));
			}
		}
	},
	
	loadPreferences: function(response) {
		if(response.showcontactmatch != undefined) {
			this.modelMatchContacts.value = response.showcontactmatch;
			
			this.controller.modelChanged(this.modelMatchContacts, this);
		}
		
		this.loadDialingShortcuts(response);
	},
	
	savePreferences: function(event) {
		this.setPreferencesRequest = new Mojo.Service.Request('palm://com.palm.systemservice/', {
			method: 'setPreferences', parameters: {showcontactmatch: this.modelMatchContacts.value}});
	},
	
	savePhonePrefs: function(event) {
		this.phonePrefs.closeApp = this.modelCloseAfter.value;
		this.phonePrefs.startView = this.modelStartView.value;
		this.phonePrefs.autoDialing = this.modelAutoDialing.value;
		this.phonePrefs.removedFromTS = this.modelTouchstoneRemove.value;
		this.phonePrefs.proximityAction = this.modelProximityAction.value;
		
		var cookieContainer = new Mojo.Model.Cookie("phone");
		
		var phonePrefs = {
			closeApp: this.modelCloseAfter.value, 
			startView: this.modelStartView.value, 
			autoDialing: this.modelAutoDialing.value, 
			removedFromTS: this.modelTouchstoneRemove.value, 
			proximityAction: this.modelProximityAction.value };
		
		cookieContainer.put(phonePrefs);
	},
	
	saveRejectedPrefs: function(event) {
		if(this.modelRejectedCall.value == "autoreply") {
			this.controller.get("RejectedCallRow").removeClassName('last');
			this.controller.get("RejectedTextRow").show();
		}
		else {
			this.controller.get("RejectedCallRow").addClassName('last');
			this.controller.get("RejectedTextRow").hide();
		}
		
		this.rejectedPrefs.rejectAction = this.modelRejectedCall.value;
		this.rejectedPrefs.rejectTemplate = this.modelRejectedText.value;
		
		this.setPreferencesRequest = new Mojo.Service.Request('palm://com.palm.systemservice/', {
			method: 'setPreferences', parameters: {callRejection: this.rejectedPrefs}});
	},
	
	loadDialingShortcuts: function(payload){
		this.dialingShortcutsList.clear();
		
		this.controller.modelChanged(this.dialingShortcutsModel);
		
		if((payload) && (payload.returnValue)) {
			delete payload.returnValue;
			
			$H(payload).each(function(pair) {
				if(pair.key && pair.value) {
					var str = pair.key.sub('DigitNumber','');
					var dispText = $L("#{NUM} digits").interpolate({NUM:parseInt(str)});
					
					this.dialingShortcutsList.push({
						value: pair.value + '-' + 'X'.times(parseInt(str)),
						text: dispText, name: pair.key});
				}
			}.bind(this));
			
			this.controller.modelChanged(this.dialingShortcutsModel);
		}
    },
	
	dialingShortCutAdded: function(obj) {
		if(!obj)
			return;
		
		//Check if it's already defined.
		var str = obj.text.sub('DigitNumber','');
		var dispText = $L("#{NUM} digits").interpolate({NUM:parseInt(str)});
		
		for(var i = 0; i<this.dialingShortcutsList.length; i++) {
			if(this.dialingShortcutsList[i].name === obj.text) {
				this.dialingShortcutsList[i].value = obj.value + '-' + 'X'.times(parseInt(str));
				this.controller.modelChanged(this.dialingShortcutsModel);
				return;
			}
		}
		
		this.dialingShortcutsList.push({
			value: obj.value + '-' + 'X'.times(parseInt(str)),
			text: dispText, name: obj.text });
		
		this.controller.modelChanged(this.dialingShortcutsModel);
	},
	
    addDialingShortcut: function(event) {
      var appController = Mojo.Controller.getAppController();
		
		var stageController = appController.getStageController("PhoneApp");
		
       stageController.pushScene('dialingshortcut', this);
    },
	
	 deleteDialingShortcut: function(event) {
		var params = {};
		
		params[event.item.name] = false;
		
		this.dialingShortcutsList.splice(event.index,1);
		
		this.setPreferencesRequest = new Mojo.Service.Request('palm://com.palm.systemservice/', {
			method: 'setPreferences', parameters: params});
    },
    
    launchPhoneAccount: function(event) {
		this.openAccountRequest = new Mojo.Service.Request('palm://com.palm.applicationManager', {
			method: 'open',
			parameters: {'id': 'com.palm.app.phoneprefs',params: {'launchType': 'phoneAccount'}}});
    },
    
    editNotifications: function(event) {
    	event.stop();
    	
      var appController = Mojo.Controller.getAppController();
		
		var stageController = appController.getStageController("PhoneApp");
		
       stageController.pushScene('notify', this.notificationPrefs);
    	
    }
});

